![Optional Text](../master/image.png)
# Dedos-attack
Ddos dengan sejuta kerinduan :*
# How To Install 
```
$pkg install python2
$pkg install git
$cd Dedos-attack
$chmod 777 serang.py
$python2 serang.py
```
Akwokwokwok
